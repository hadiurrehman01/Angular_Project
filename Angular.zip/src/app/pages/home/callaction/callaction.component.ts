import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-callaction',
  templateUrl: './callaction.component.html',
  styleUrls: ['./callaction.component.scss']
})
export class CallactionComponent implements OnInit {
  name = 'inintila value'
  constructor() { }

  ngOnInit() {
  }

}
